
package gymmanagement;
import static gymmanagement.MainLogin.CustomerL;
import static gymmanagement.MainLogin.CustomerO;
import static gymmanagement.MainLogin.*;
import static gymmanagement.UserDetails.*;
import static gymmanagement.UserLogin.*;
import static gymmanagement.UserRegister.*;
import static gymmanagement.GymManagement.*;
import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
public class ChangeSlotUser extends javax.swing.JFrame {

    /**
     * Creates new form ChnageSlotUser
     */
    public ChangeSlotUser() {
        initComponents();
        trainers();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        slot = new javax.swing.JComboBox<>();
        trainer = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        slot.setBackground(new java.awt.Color(255, 255, 204));
        slot.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        slot.setForeground(new java.awt.Color(0, 0, 153));
        slot.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "(M1)Unisex", "(M2)Male", "(M3)Female", "(E1)Unisex", "(E2)Male", "(E3)Female" }));
        slot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                slotActionPerformed(evt);
            }
        });
        getContentPane().add(slot, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 220, 330, 60));

        trainer.setBackground(new java.awt.Color(255, 255, 204));
        trainer.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        trainer.setForeground(new java.awt.Color(0, 0, 153));
        trainer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        trainer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trainerActionPerformed(evt);
            }
        });
        getContentPane().add(trainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 370, 330, 60));

        jLabel15.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("Slot");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, 159, 39));

        jLabel16.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Trainer");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 213, 40));

        jButton1.setBackground(new java.awt.Color(255, 204, 153));
        jButton1.setFont(new java.awt.Font("STZhongsong", 3, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 102, 102));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/submit.jpg"))); // NOI18N
        jButton1.setText("Submit");
        jButton1.setIconTextGap(20);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 550, 310, 60));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 0));
        jLabel1.setText("Please Enter Your Preferences");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 560, 80));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/gym wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1110, 690));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    public void trainers(){
        
           String [] str=new String [chec.size()];
           int i=0;
            for(TrainerDetails A: chec){
                if(choice==1){
                    if(A.u1>0){
                        str[i]=A.getUsername();
                        i++;
                    }
                }
                
                if(choice==2){
                    if(A.b1>0){
                        str[i]=A.getUsername();
                        i++;
                    }
                }
                
                if(choice==3){
                    if(A.g1>0){
                        str[i]=A.getUsername();
                        i++;
                    }
                }
                
                if(choice==4){
                    if(A.u2>0){
                        str[i]=A.getUsername();
                        i++;
                    }
                }
                
                if(choice==5){
                    if(A.b2>0){
                        str[i]=A.getUsername();
                        i++;
                    }
                }
                
                if(choice==6){
                    if(A.g2>0){
                        str[i]=A.getUsername();
                        i++;
                    }
                }
                
            }
        
           trainer.setModel(new javax.swing.DefaultComboBoxModel<>(str)); 
    }
    
    int choice=1;
    ArrayList<TrainerDetails>chec=U1;
    
    private void slotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_slotActionPerformed
        // TODO add your handling code here:
        
        if(slot.getSelectedIndex()==0)
        {
            choice=1;
            chec=U1;
        }

        if(slot.getSelectedIndex()==1)
        {
            choice=2;
            chec=B1;
        }
        if(slot.getSelectedIndex()==2)
        {
            choice=3;
            chec=G1;
        }

        if(slot.getSelectedIndex()==3)
        {
            choice=4;
            chec=U2;
        }

        if(slot.getSelectedIndex()==4)
        {
            choice=5;
            chec=B2;
        }

        if(slot.getSelectedIndex()==5)
        {
            choice=6;
            chec=G2;
        }

        trainers();
        System.out.println(U1.size());
        System.out.println(B1.size());
        System.out.println(G1.size());
        System.out.println(U2.size());
        System.out.println(B2.size());
        System.out.println(G2.size());
    }//GEN-LAST:event_slotActionPerformed

    private void trainerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trainerActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_trainerActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        TrainerDetails obj=TrainerO.get((String)trainer.getSelectedItem());
        //U.setAssT(obj);
        if(obj==null || U==null){
            System.out.println((String)trainer.getSelectedItem());
            this.dispose();
        }
        obj=U.getAssT();
        obj.Cust.remove(U.getUs());
        if(true){
        if(U.getCh()==1){
            obj.u1+=1;
        }

        if(U.getCh()==2){
            obj.b1+=1;
        }

        if(U.getCh()==3){
            obj.g1+=1;
        }

        if(U.getCh()==4){
            obj.u2+=1;
        }

        if(U.getCh()==5){
            obj.b2+=1;
        }
        if(U.getCh()==6){
            obj.g2+=1;
        }
        }
        obj=TrainerO.get((String)trainer.getSelectedItem());
        U.setAssT(obj);
        
        if(choice==1){
            obj.u1-=1;
        }
        
        if(choice==2){
            obj.b1-=1;
        }
        
        if(choice==3){
            obj.g1-=1;
        }
        
        if(choice==4){
            obj.u2-=1;
        }
        
        if(choice==5){
            obj.b2-=1;
        }
        if(choice==6){
            obj.g2-=1;
        }
        
        U.setTrain(U.getAssT().getUsername());
        UserForm r=new UserForm();
        r.setVisible(true);
        r.pack();
        r.setLocationRelativeTo(null);  
        this.dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ChangeSlotUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ChangeSlotUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ChangeSlotUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ChangeSlotUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChangeSlotUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JComboBox<String> slot;
    private javax.swing.JComboBox<String> trainer;
    // End of variables declaration//GEN-END:variables
}
