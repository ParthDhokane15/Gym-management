
package gymmanagement;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import static gymmanagement.GymManagement.*;
import static gymmanagement.Trainerregister.loadtrainer;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JFrame;


public class MainLogin extends javax.swing.JFrame {

    public static ArrayList<TrainerDetails> U1 = new ArrayList<TrainerDetails>();
    public static ArrayList<TrainerDetails> B1 = new ArrayList<TrainerDetails>();
    public static ArrayList<TrainerDetails> G1 = new ArrayList<TrainerDetails>();
    public static ArrayList<TrainerDetails> U2 = new ArrayList<TrainerDetails>();
    public static ArrayList<TrainerDetails> B2 = new ArrayList<TrainerDetails>();
    public static ArrayList<TrainerDetails> G2 = new ArrayList<TrainerDetails>();
    public static HashMap<String, String> AdminL = new HashMap<String, String>();
    public static HashMap<String, String> TrainerL = new HashMap<String, String>();
    public static HashMap<String, String> CustomerL = new HashMap<String, String>();
    public static HashMap<String, TrainerDetails> TrainerO = new HashMap<>();
    public static HashMap<String, UserDetails> CustomerO = new HashMap<>();
    
    //Addition
    private boolean isPasswordShown = false;
    //

    public MainLogin() {
        initComponents();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        pass = new javax.swing.JPasswordField();
        AdminLogin = new javax.swing.JRadioButton();
        TrainerLogin = new javax.swing.JRadioButton();
        CustomerLogin = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        user = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(102, 204, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/login.jpg"))); // NOI18N
        jButton1.setText("Login");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 760, 212, 66));

        jLabel1.setFont(new java.awt.Font("Cambria Math", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Password");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 620, 220, 60));

        jButton3.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jButton3.setForeground(new java.awt.Color(102, 204, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/exit.jpg"))); // NOI18N
        jButton3.setText("EXIT");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1350, 760, -1, 66));

        pass.setBackground(new java.awt.Color(255, 255, 204));
        pass.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        pass.setForeground(new java.awt.Color(0, 0, 204));
        pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passActionPerformed(evt);
            }
        });
        getContentPane().add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 620, 350, 60));

        AdminLogin.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        AdminLogin.setSelected(true);
        AdminLogin.setText("Admin");
        AdminLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AdminLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/admin.jpg"))); // NOI18N
        AdminLogin.setIconTextGap(20);
        AdminLogin.setNextFocusableComponent(AdminLogin);
        AdminLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminLoginActionPerformed(evt);
            }
        });
        getContentPane().add(AdminLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 170, 280, 70));

        TrainerLogin.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        TrainerLogin.setText("Trainer");
        TrainerLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TrainerLogin.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        TrainerLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/trainer.jpg"))); // NOI18N
        TrainerLogin.setIconTextGap(20);
        TrainerLogin.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                TrainerLoginStateChanged(evt);
            }
        });
        TrainerLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrainerLoginActionPerformed(evt);
            }
        });
        TrainerLogin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TrainerLoginKeyPressed(evt);
            }
        });
        getContentPane().add(TrainerLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 370, 290, -1));

        CustomerLogin.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        CustomerLogin.setText("Customer");
        CustomerLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CustomerLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/customer.jpg"))); // NOI18N
        CustomerLogin.setIconTextGap(20);
        CustomerLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerLoginActionPerformed(evt);
            }
        });
        getContentPane().add(CustomerLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 270, 290, -1));

        jLabel3.setBackground(new java.awt.Color(204, 255, 204));
        jLabel3.setFont(new java.awt.Font("Cambria Math", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Enter Your Account Details");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 480, 540, 50));

        user.setBackground(new java.awt.Color(255, 255, 204));
        user.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        user.setForeground(new java.awt.Color(0, 0, 204));
        user.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userActionPerformed(evt);
            }
        });
        getContentPane().add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 540, 350, 60));

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("  Welcome To Fitness Plus GYM");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 40, 527, 78));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/temp.jpg"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 840));
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 420));

        jToggleButton1.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jToggleButton1.setForeground(new java.awt.Color(102, 204, 255));
        jToggleButton1.setText("Show Password");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jToggleButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 680, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/select_role.jpg"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 210, 260, 240));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("Please Select Your Role");
        jTextField1.setBorder(null);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 170, 260, 60));

        jLabel5.setBackground(new java.awt.Color(204, 255, 204));
        jLabel5.setFont(new java.awt.Font("Cambria Math", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Username");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 550, 210, 50));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        if (user.getText().isEmpty() || pass.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter all fields");
        } else {
            try {
                String username = user.getText().trim();
                String password = pass.getText().trim();
                if (AdminLogin.isSelected()) {
                    if (AdminL.containsKey(username)) {
                        if (AdminL.get(username).equals(password)) {
                            new AdminFront().setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Password Doesn't Match");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Such Username Exist");
                    }
                } else if (TrainerLogin.isSelected()) {
                    if (TrainerL.containsKey(username)) {
                        if (TrainerL.get(username).equals(password)) {
                            GymManagement.T = TrainerO.get(username);
                            new Trainer().setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Password Doesn't Match");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Such Username Exist");
                    }
                } else if (CustomerLogin.isSelected()) {
                    if (CustomerL.containsKey(username)) {
                        if (CustomerL.get(username).equals(password)) {
                            U = CustomerO.get(username);
                            new UserForm().setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Password Doesn't Match");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No Such Username Exist");
                    }

                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        
    }//GEN-LAST:event_passActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        
        ButtonGroup GP1 = new ButtonGroup();
        GP1.add(AdminLogin);
        GP1.add(TrainerLogin);
        GP1.add(CustomerLogin);
        AdminL.put("admin", "1234");
        AdminL.put("yash", "1234");
        
        // Add default customer "yash" with password "1234"
        CustomerL.put("yash", "1234");

        loadtrainer();
        UserLogin.load();
        

    }//GEN-LAST:event_formWindowOpened

    
    private void AdminLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminLoginActionPerformed
       // Add the following line to change the background color
   changeButtonColor(AdminLogin);
    TrainerLogin.setBackground(UIManager.getColor("Button.background")); // Reset color for other buttons
    CustomerLogin.setBackground(UIManager.getColor("Button.background")); // Reset color for other buttons
        
    }//GEN-LAST:event_AdminLoginActionPerformed

    private void CustomerLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerLoginActionPerformed
          // Add the following line to change the background color
    changeButtonColor(CustomerLogin);
    AdminLogin.setBackground(UIManager.getColor("Button.background")); // Reset color for other buttons
    TrainerLogin.setBackground(UIManager.getColor("Button.background")); // Reset color for other buttons
    }//GEN-LAST:event_CustomerLoginActionPerformed

    private void userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userActionPerformed
       
    }//GEN-LAST:event_userActionPerformed

    private void TrainerLoginKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TrainerLoginKeyPressed
        
        // TODO add your handling code here:
    }//GEN-LAST:event_TrainerLoginKeyPressed

    private void TrainerLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrainerLoginActionPerformed
    changeButtonColor(TrainerLogin);
    CustomerLogin.setBackground(UIManager.getColor("Button.background")); // Reset color for other buttons
    AdminLogin.setBackground(UIManager.getColor("Button.background")); // Reset color for other buttons
    }//GEN-LAST:event_TrainerLoginActionPerformed

    private void TrainerLoginStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_TrainerLoginStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_TrainerLoginStateChanged

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        // TODO add your handling code here:
        isPasswordShown = !isPasswordShown; // Toggle the state

    if (isPasswordShown) {
        pass.setEchoChar((char) 0); // Show the password
    } else {
        pass.setEchoChar('*'); // Hide the password
    }
    
    
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
        // TODO add your handling code here:
          getContentPane().setBackground(Color.WHITE);
          setSize(1366, 768);
          setLocationRelativeTo(null); // Center the JFrame on the screen
            setResizable(false); // Disable resizing
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setUndecorated(true);
    }//GEN-LAST:event_formWindowGainedFocus
   
    private void changeButtonColor(javax.swing.JRadioButton button) {
    if (button.isSelected()) {
        button.setBackground(new java.awt.Color(0, 102, 204)); // Blue color for selected state
    } else {
        button.setBackground(UIManager.getColor("Button.background")); // Default button background color for deselected state
    }
}
   

   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton AdminLogin;
    private javax.swing.JRadioButton CustomerLogin;
    private javax.swing.JRadioButton TrainerLogin;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JPasswordField pass;
    private javax.swing.JTextField user;
    // End of variables declaration//GEN-END:variables
}
