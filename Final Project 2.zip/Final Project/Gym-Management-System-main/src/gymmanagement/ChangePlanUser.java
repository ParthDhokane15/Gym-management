
package gymmanagement;
import static gymmanagement.MainLogin.*;
import static gymmanagement.MainLogin.U1;
import static gymmanagement.UserDetails.*;
import static gymmanagement.UserLogin.*;
import static gymmanagement.GymManagement.*;
import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
/**
 *
 * @author
 */
public class ChangePlanUser extends javax.swing.JFrame {

    /**
     * Creates new form ChangePlanUser
     */
    public ChangePlanUser() {
        initComponents();
        
        String str3[]=new String[3];
        
        str3[0]="Basic";
        str3[1]="Mid";
        str3[2]="Mega";
        
         pl.setModel(new javax.swing.DefaultComboBoxModel<>(str3));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pl = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("FITNESS PLUS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 54, 424, 71));

        jLabel2.setFont(new java.awt.Font("STLiti", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Change Membership To");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(348, 154, 530, 70));

        pl.setBackground(new java.awt.Color(255, 255, 204));
        pl.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        pl.setForeground(new java.awt.Color(0, 0, 153));
        pl.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        pl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                plActionPerformed(evt);
            }
        });
        getContentPane().add(pl, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 1165, 78));

        jButton1.setBackground(new java.awt.Color(255, 204, 153));
        jButton1.setFont(new java.awt.Font("Sitka Text", 3, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 102, 102));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/submit.jpg"))); // NOI18N
        jButton1.setText("Submit");
        jButton1.setIconTextGap(20);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 480, 250, 60));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/gym wallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 0, 1260, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
        String plan=(String)pl.getSelectedItem();
        
        int i;
        U.setMemberShip(plan);
//        for(i=0;i<user.size();i++)
//        {
//            if(us.getUs().equals(user.get(i).getUs()))
//            {
//                user.get(i).setPlan(plan);
//                break;
//            }
//        }
        
        
        
        UserForm r=new UserForm();
        r.setVisible(true);
        r.pack();
        r.setLocationRelativeTo(null);  
        this.dispose();
        //this.dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void plActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_plActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChangePlanUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JComboBox<String> pl;
    // End of variables declaration//GEN-END:variables
}
