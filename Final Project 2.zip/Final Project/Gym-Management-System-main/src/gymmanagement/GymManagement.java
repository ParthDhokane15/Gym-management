
package gymmanagement;


public class GymManagement {

    
   public static TrainerDetails T = null;
    public static UserDetails U = null;

    public static void main(String[] args) {
        
              new MainLogin().setVisible(true);

              
    }

} 
