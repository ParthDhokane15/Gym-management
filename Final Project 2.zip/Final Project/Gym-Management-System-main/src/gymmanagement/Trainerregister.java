
package gymmanagement;

import static gymmanagement.MainLogin.*;
import static gymmanagement.TrainerDetails.tr;
import static gymmanagement.UserDetails.user;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Trainerregister extends javax.swing.JFrame {

    public Trainerregister() {
        initComponents();
         String[] Com = new String[2];
        Com[0]="Male";
        Com[1]="Female";
        combo.setModel(new javax.swing.DefaultComboBoxModel<>(Com));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        user = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        nam = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        ag = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        contactno = new javax.swing.JTextField();
        combo = new javax.swing.JComboBox<>();
        confirmpass = new javax.swing.JPasswordField();
        pass = new javax.swing.JPasswordField();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 204, 204));
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                formComponentAdded(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Email");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 424, 174, 35));

        jLabel2.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 68, 174, 35));

        jLabel3.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("User Name");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 127, 174, 35));

        jLabel4.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Gender");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, 174, 35));

        jLabel5.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Confirm Password");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 550, 240, 35));

        jLabel6.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Password");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 489, 174, 35));

        user.setBackground(new java.awt.Color(255, 255, 204));
        user.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        user.setForeground(new java.awt.Color(0, 0, 204));
        user.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userActionPerformed(evt);
            }
        });
        getContentPane().add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, 720, 40));

        email.setBackground(new java.awt.Color(255, 255, 204));
        email.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        email.setForeground(new java.awt.Color(0, 0, 204));
        email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 420, 720, 41));

        nam.setBackground(new java.awt.Color(255, 255, 204));
        nam.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        nam.setForeground(new java.awt.Color(0, 0, 204));
        nam.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namActionPerformed(evt);
            }
        });
        getContentPane().add(nam, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 50, 720, 40));

        jButton1.setBackground(new java.awt.Color(204, 255, 204));
        jButton1.setFont(new java.awt.Font("Calisto MT", 1, 48)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/register.jpg"))); // NOI18N
        jButton1.setText("Register");
        jButton1.setAlignmentX(0.5F);
        jButton1.setIconTextGap(20);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 640, 390, 70));

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 3, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Enter Your Details");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 322, 47));

        jLabel8.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Contact No");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 174, 43));

        ag.setBackground(new java.awt.Color(255, 255, 204));
        ag.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        ag.setForeground(new java.awt.Color(0, 0, 204));
        ag.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agActionPerformed(evt);
            }
        });
        getContentPane().add(ag, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 250, 260, 41));

        jLabel9.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Age");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, 174, 35));

        contactno.setBackground(new java.awt.Color(255, 255, 204));
        contactno.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        contactno.setForeground(new java.awt.Color(0, 0, 204));
        contactno.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        contactno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactnoActionPerformed(evt);
            }
        });
        getContentPane().add(contactno, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 350, 260, 41));

        combo.setBackground(new java.awt.Color(255, 255, 204));
        combo.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 36)); // NOI18N
        combo.setForeground(new java.awt.Color(0, 0, 204));
        combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(combo, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 190, 260, 38));

        confirmpass.setBackground(new java.awt.Color(255, 255, 204));
        confirmpass.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        confirmpass.setForeground(new java.awt.Color(0, 0, 204));
        confirmpass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        confirmpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmpassActionPerformed(evt);
            }
        });
        getContentPane().add(confirmpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 550, 720, 40));

        pass.setBackground(new java.awt.Color(255, 255, 204));
        pass.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        pass.setForeground(new java.awt.Color(0, 0, 204));
        pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passActionPerformed(evt);
            }
        });
        getContentPane().add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 480, 720, 40));

        jLabel10.setBackground(new java.awt.Color(255, 204, 204));
        jLabel10.setForeground(new java.awt.Color(255, 204, 204));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gymmanagement/image/gym wallpaper.jpg"))); // NOI18N
        jLabel10.setAlignmentY(0.0F);
        jLabel10.setIconTextGap(0);
        jLabel10.setMaximumSize(new java.awt.Dimension(1500, 1500));
        jLabel10.setMinimumSize(getMaximumSize());
        jLabel10.setPreferredSize(new java.awt.Dimension(1500, 1500));
        jLabel10.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jLabel10PropertyChange(evt);
            }
        });
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -100, 1510, 1500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userActionPerformed
        
    }//GEN-LAST:event_userActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        
    }//GEN-LAST:event_emailActionPerformed

    private void namActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namActionPerformed
        
    }//GEN-LAST:event_namActionPerformed

    boolean validate(String email) {
        String reg = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

        return email.matches(reg);
    }

    static void loadtrainer() {
        File fd = new File("src/gymmanagement/trainer");

        try {
            Scanner s = new Scanner(fd);
            while (s.hasNextLine()) {
                String d=s.nextLine();
                String [] input=d.split(" ");
                String name=input[0];
                
                String use=input[1];
                String gen=input[2];
                String age=input[3];
                String con=input[4];
                String ema=input[5];
                String ps=input[6];
                
      
                //UserDetails us=new UserDetails(names,userName,password,gender,age,address);
                //JOptionPane.showMessageDialog(null,u);
                TrainerDetails obj = new TrainerDetails(name, use, gen, age, con, ema, ps);
                //JOptionPane.showMessageDialog(null,u);
                
                TrainerL.put(use,ps);
                TrainerO.put(use,obj);
                if (gen.equalsIgnoreCase("male")) {
                            obj.u1 = 4;
                            obj.b1 = 4;
                            obj.u2 = 4;
                            obj.b2 = 4;
                            U1.add(obj);
                            B1.add(obj);
                            B2.add(obj);
                            U2.add(obj);
                            
                        } else {
                            obj.u1 = 4;
                            obj.g1 = 4;
                            obj.u2 = 4;
                            obj.g2 = 4;
                            U1.add(obj);
                            G1.add(obj);
                            G2.add(obj);
                            U2.add(obj);

                        }
                
            }
        } catch (Exception e) {
            System.out.println("IO Exception");
        }
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

        if (nam.getText().isEmpty() || user.getText().isEmpty() || ag.getText().isEmpty() || contactno.getText().isEmpty() || email.getText().isEmpty() || confirmpass.getText().isEmpty() || pass.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter all fields");
        } else {
            try {
                String name = nam.getText().trim();
                String username = user.getText().trim();
                String gen = (String) combo.getSelectedItem();
                String ema = email.getText().trim();
                String password = pass.getText().trim();
                String contact = contactno.getText().trim();
                String age = ag.getText().trim();
                String cpassword = confirmpass.getText().trim();
                File fd = new File("src/gymmanagement/trainer");
                Scanner scan = new Scanner(fd);

                if (!password.equals(cpassword)) {
                    JOptionPane.showMessageDialog(null, "Password doesn't matches");
                } else if (!validate(ema)) {
                    JOptionPane.showMessageDialog(null, "Enter a valid email Id");
                } else {

                    TrainerDetails obj = new TrainerDetails(name, username, gen, age, contact, ema, password);
                    int flag = 1;
                    int n = tr.size();
                    for (int i = 0; i < n; i++) {

                        if (tr.get(i).getUsername().equals(username)) {
                            flag = 0;
                            JOptionPane.showMessageDialog(null, "Username already exists Please enter the username again");
                            break;

                        }
                    }
                    if (flag == 1) {

                        tr.add(obj);
                        TrainerL.put(username, password);
                        TrainerO.put(username, obj);
                        FileWriter f = new FileWriter("src/gymmanagement/trainer", true);
                   
                        f.append(name + " " + username + " " + gen + " " + age + " " + contact + " " + ema + " " + password + "\n");
                        f.close();
                        if (gen.equalsIgnoreCase("male")) {
                            obj.u1 = 4;
                            obj.b1 = 4;
                            obj.u2 = 4;
                            obj.b2 = 4;
                            U1.add(obj);
                            B1.add(obj);
                            B2.add(obj);
                            U2.add(obj);
                            
                        } else {
                            obj.u1 = 4;
                            obj.g1 = 4;
                            obj.u2 = 4;
                            obj.g2 = 4;
                            U1.add(obj);
                            G1.add(obj);
                            G2.add(obj);
                            U2.add(obj);

                        }
                        JOptionPane.showMessageDialog(null, "Succesfully Added");
                        new Trainer().setVisible(true);
                        this.dispose();

                    } else {
                        JOptionPane.showMessageDialog(null, "Enter username or password is wrong");
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }

        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void agActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_agActionPerformed

    private void contactnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contactnoActionPerformed

    private void confirmpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmpassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirmpassActionPerformed

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passActionPerformed

    private void formComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentAdded

    private void jLabel10PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jLabel10PropertyChange
       
    }//GEN-LAST:event_jLabel10PropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Trainerregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Trainerregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Trainerregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Trainerregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Trainerregister().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ag;
    private javax.swing.JComboBox<String> combo;
    private javax.swing.JPasswordField confirmpass;
    private javax.swing.JTextField contactno;
    private javax.swing.JTextField email;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField nam;
    private javax.swing.JPasswordField pass;
    private javax.swing.JTextField user;
    // End of variables declaration//GEN-END:variables
}
